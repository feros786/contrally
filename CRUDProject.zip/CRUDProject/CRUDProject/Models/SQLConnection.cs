﻿namespace CRUDProject.Models
{
    internal class SQLConnection
    {
        public SQLConnection(string strConString)
        {
            StrConString = strConString;
        }

        public string StrConString { get; }
    }
}